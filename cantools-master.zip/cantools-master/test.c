#include <stdio.h>

int
main()
{
	fclose(stdin);
	return 0;
}
